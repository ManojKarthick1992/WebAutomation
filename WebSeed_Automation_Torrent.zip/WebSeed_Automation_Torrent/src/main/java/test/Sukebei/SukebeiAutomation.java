package test.Sukebei;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

/************************************************************************************************************************
 * Code for Creating Torrent file using WebTorrent Hybrid CLI, Uploading
 * Video/Torrent file to wasabi using AWS CLI and updating the magnet link to
 * MongoDB
 ************************************************************************************************************************/
@SuppressWarnings("deprecation")
public class SukebeiAutomation {
	public static void main(String[] args) throws IOException, InterruptedException, ParseException {

		Properties prop = CommonUtilities.ReadInputData.readPropertiesFile();
		String targetDirectoryFolder = prop.getProperty("target_directory_Folder").trim();
		String url = prop.getProperty("FCP_url").trim();
		String transmissionFolder = prop.getProperty("transmissionFolder").trim();
		String trackerInfo = prop.getProperty("tracker_Info").trim();
		String fcpUpload = prop.getProperty("FCP_upload").trim();
		String fcpuser = prop.getProperty("fcp_user").trim();
		String fcppswd = prop.getProperty("fcp_password").trim();
		downloadData(url, targetDirectoryFolder, transmissionFolder, trackerInfo, fcpUpload, fcpuser, fcppswd);
	}

	/*************************************************************************************************************************
	 * createTorrentWebSeed() -
	 * 
	 ************************************************************************************************************************/
	@SuppressWarnings({ "resource", "unchecked", "rawtypes" })
	public static void downloadData(String URL, String sourceDirectory, String transmissionFolder, String trackerInfo,
			String fcpUpload, String fcpuser, String fcppswd) {
		try {
			// Defining Logging related object functions
			Logger logger = Logger.getLogger("MyLog");
			FileHandler fh;
			try {
				// This block configure the logger with handler and formatter
				fh = new FileHandler("Logs//" + "Log_" + getCurrentDate() + ".txt");
				logger.addHandler(fh);
				SimpleFormatter formatter = new SimpleFormatter();
				fh.setFormatter(formatter);
			} catch (Exception e) {
				e.printStackTrace();
			}

			// Navigating to FCP WebSite for downloading the data
			WebDriver driver;
			String homePath = System.getProperty("user.dir");
			System.setProperty("webdriver.chrome.driver", homePath + "\\Drivers\\chromedriver.exe");
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("intl.accept_languages", "ja");
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("prefs", chromePrefs);
			driver = new ChromeDriver(options);
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get(URL);
			FluentWait wait = new FluentWait<WebDriver>(driver).withTimeout(25, TimeUnit.SECONDS)
					.pollingEvery(3, TimeUnit.SECONDS).ignoring(Exception.class);
			try {
				if (driver.findElements(By.xpath("//h1[text()='502 Bad Gateway']")).size() > 0) {
					driver.navigate().refresh();
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//th[text()='Category']")));
			} catch (Exception e) {
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//th[text()='Category']")));
			}
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//td[contains(text(),'" + getPastDate(1) + "')]")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath("//td[contains(text(),'" + getPastDate(1) + "')]/preceding-sibling::td[2]/a[2]")));
			java.util.List<WebElement> magnetLinks = driver.findElements(
					By.xpath("//td[contains(text(),'" + getPastDate(1) + "')]/preceding-sibling::td[2]/a[2]"));
			java.util.List<WebElement> videoTitle = driver.findElements(
					By.xpath("//td[contains(text(),'" + getPastDate(1) + "')]/preceding-sibling::td[3]/a"));

			// Navigating through Magnet Link and Proceed further
			for (int i = 0; i < magnetLinks.size(); i++) {
				magnetLinks = driver.findElements(
						By.xpath("//td[contains(text(),'" + getPastDate(1) + "')]/preceding-sibling::td[2]/a[2]"));
				videoTitle = driver.findElements(
						By.xpath("//td[contains(text(),'" + getPastDate(1) + "')]/preceding-sibling::td[3]/a"));
				logger.info("Fetched Yesterday Video with Maget URI :" + magnetLinks.get(i).getAttribute("href")
						+ " and Title:" + videoTitle.get(i).getText());
				String magnetLink = magnetLinks.get(i).getAttribute("href");
				String[] folderName = videoTitle.get(i).getText().split(" ");
				String directoryName = sourceDirectory + "\\" + folderName[1];
				char quotes = '"';
				String updatedName = videoTitle.get(i).getText().replace("+++", "[solji.kim]");

				// Fetching Hash Info
				String[] a = magnetLink.split("btih:");
				String[] b = a[1].split("&dn=");

				// Downloading the Files from FCP WebPage
				String command1 = "transmission-remote -a " + quotes + magnetLink + quotes + " --download-dir "
						+ sourceDirectory;
				System.out.println(command1);
				logger.info(command1);

				// Executing the commands for creating the torrent File
				String[] cmd1 = new String[3];
				cmd1[0] = "cmd";
				cmd1[1] = "/c";
				cmd1[2] = "cd " + transmissionFolder + " && " + command1;
				Process process = Runtime.getRuntime().exec(cmd1);
				logger.info("Downloding File " + folderName[1] + " from FC2 Website");

				// Reading the Command line Response to Check if the Download has started
				BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				String json = "";
				String s = null;
				while ((s = reader.readLine()) != null) {
					json = json + s;
					System.out.println(json);
					logger.info(json);
				}
				BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
				String Error;
				while ((Error = stdError.readLine()) != null) {
					logger.info("Error while Downloading the files to FCP WebPage:" + Error);
				}

				// Wait Until the video Completes
				logger.info("Waiting Until Video is downloaded");
				checkVideoCompleted(transmissionFolder);
				logger.info("Completed with Video Download:" + folderName[1]);
				
				// Removing the Torrent List
				String command = "transmission-remote -t "+b[0]+" -r";
				logger.info(command);

				// Executing the commands for creating the torrent File
				String[] cmd = new String[3];
				cmd[0] = "cmd";
				cmd[1] = "/c";
				cmd[2] = "cd " + transmissionFolder + " && " + command;
				process = Runtime.getRuntime().exec(cmd);
				logger.info("Removing the Torrent from List");
				
				stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
				while ((Error = stdError.readLine()) != null) {
					logger.info("Error while Removing the Torrent from List" + Error);
				}
				
				// Check whether video file exists and Copy the PDF files
				isFolderExists(directoryName);
				isDeleteOtherFiles(directoryName);
				logger.info("Deleted other files and copies PDF Files");

				// Creating a Torrent File
				String filePath = sourceDirectory + "\\" + folderName[1] + ".torrent";
				String filePath1 = sourceDirectory + "\\" + folderName[1] + "\\";
				File myFile = new File(filePath1);

				System.out.println(myFile.getCanonicalPath());
				String command2 = "transmission-create -o " + filePath + " " + trackerInfo + " "
						+ myFile.getCanonicalPath();
				logger.info(command2);
				logger.info("Creating Torrent file for " + folderName[1]);

				// Executing the commands for creating the torrent File
				String[] cmd2 = new String[3];
				cmd2[0] = "cmd";
				cmd2[1] = "/c";
				cmd2[2] = "cd " + transmissionFolder + " && " + command2;
				Thread.sleep(4000);
				process = Runtime.getRuntime().exec(cmd2);

				// Reading the Command line Response
				reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				json = "";
				s = null;
				while ((s = reader.readLine()) != null) {
					json = json + s;
					System.out.println(json);
					logger.info(json);
				}
				stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
				while ((Error = stdError.readLine()) != null) {
					logger.info("Error while creating a Torrent FIle" + Error);
				}

				// Wait until Torrent File is created
				File file1 = new File(sourceDirectory + "\\" + folderName[1] + ".torrent");
				isFileExists(file1);
				logger.info("Created Torrent file for " + folderName[1]);
				
				// Fetch the HashInfo from Command Line Response
				String command4 = "webtorrent-hybrid info " + sourceDirectory + "\\" + folderName[1]  + ".torrent";
				logger.info("Fetching the Hash Info value from Torrent File");
				logger.info(command4);
				String[] cmd4 = new String[3];
				cmd4[0] = "cmd";
				cmd4[1] = "/c";
				cmd4[2] = "cd " + transmissionFolder + " && " + command4;
				process = Runtime.getRuntime().exec(cmd4);

				// Reading the Command line Response and getting Hash Info Value
				reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				while ((s = reader.readLine()) != null) {
					json = json + s;
				}
				JSONObject jObject = new JSONObject(json);
				String hashInfo = jObject.get("infoHash").toString();

				// Start the Seeding
				String command3 = "transmission-remote -t " + hashInfo + " --start";
				System.out.println(command3);
				String[] cmd3 = new String[3];
				cmd3[0] = "cmd";
				cmd3[1] = "/c";
				cmd3[2] = "cd " + transmissionFolder + " && " + command3;
				Thread.sleep(4000);
				process = Runtime.getRuntime().exec(cmd3);

				// Reading the Command line Response
				reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				json = "";
				s = null;
				while ((s = reader.readLine()) != null) {
					json = json + s;
					System.out.println(json);
					logger.info(json);
					logger.info("Completed Seeding for Torrent file " + folderName[1]);
				}
				stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
				while ((Error = stdError.readLine()) != null) {
					logger.info("Error while Seeding the Torrent FIle" + Error);
				}

				// Opening Upload Page in a new Tab
				if (i == 0 || driver.findElements(By.xpath("//a[contains(@href,'login')]")).size() > 0) {
					logger.info("Opening FCP Login Page for Login with User");
					driver.get("https://sukebei.nyaa.si/login");
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@name='username']")));
					driver.findElement(By.xpath("//input[@name='username']")).sendKeys(fcpuser);
					driver.findElement(By.xpath("//input[@name='password']")).sendKeys(fcppswd);
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='submit']")));
					driver.findElement(By.xpath("//input[@type='submit']")).click();
					Thread.sleep(3000);
				}

				String description = "[![IMAGE ALT TEXT HERE](https://apipuncmedia.s3-ap-northeast-1.amazonaws.com/fc2_snapshot/"
						+ folderName[1] + "-01.jpg)](https://solji.kim)\r\n"
						+ "[![IMAGE ALT TEXT HERE](https://apipuncmedia.s3-ap-northeast-1.amazonaws.com/fc2_snapshot/"
						+ folderName[1] + "-02.jpg)](https://solji.kim)\r\n"
						+ "[![IMAGE ALT TEXT HERE](https://apipuncmedia.s3-ap-northeast-1.amazonaws.com/fc2_snapshot/"
						+ folderName[1] + "-03.jpg)](https://solji.kim)\r\n"
						+ "[![IMAGE ALT TEXT HERE](https://apipuncmedia.s3-ap-northeast-1.amazonaws.com/fc2_snapshot/solji.kim_main_1279x687.jpg)](https://solji.kim)\r\n"
						+ "[![IMAGE ALT TEXT HERE](https://apipuncmedia.s3-ap-northeast-1.amazonaws.com/fc2_snapshot/solji.kim_KO.png)](https://solji.kim)\r\n"
						+ "[![IMAGE ALT TEXT HERE](https://apipuncmedia.s3-ap-northeast-1.amazonaws.com/fc2_snapshot/solji.kim_JP.png)](https://solji.kim)\r\n"
						+ "[![IMAGE ALT TEXT HERE](https://apipuncmedia.s3-ap-northeast-1.amazonaws.com/fc2_snapshot/solji.kim_EN.png)](https://solji.kim)\r\n"
						+ "[![IMAGE ALT TEXT HERE](https://apipuncmedia.s3-ap-northeast-1.amazonaws.com/fc2_snapshot/solji.kim_CN.png)](https://solji.kim)\r\n"
						+ "[![IMAGE ALT TEXT HERE](https://apipuncmedia.s3-ap-northeast-1.amazonaws.com/fc2_snapshot/solji.kim_TW.png)](https://solji.kim)";

				System.out.println(description);

				// Login to Page
				logger.info("Opening FCP Upload Page for Torrent FIle Upload");
				driver.get("https://sukebei.nyaa.si/upload");
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Browse')]")));
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Browse')]")));
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='torrent_file']")));
				driver.findElement(By.xpath("//input[@id='torrent_file']")).sendKeys(filePath);
				driver.findElement(By.xpath("//input[@name='display_name']")).sendKeys(updatedName);
				driver.findElement(By.xpath("//input[@name='information']")).sendKeys("https://solji.kim");
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@name='category']")));
				Select values = new Select(driver.findElement(By.xpath("//select[@name='category']")));
				values.selectByVisibleText("Real Life - Videos");
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@name='description']")));
				driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys(description);
				Thread.sleep(3000);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='submit']")));
				driver.findElement(By.xpath("//input[@type='submit']")).click();
				Thread.sleep(4000);
				try {
					driver.findElement(By.xpath("//input[@type='submit']")).click();
					Thread.sleep(4000);
				} catch (Exception e) {
					e.printStackTrace();
				}
				// Login back to Page
				logger.info("Navigating back to FCP WebPage for Scrapping the data");
				driver.get(URL);
				Thread.sleep(2000);
				try {
					if (driver.findElements(By.xpath("//h1[text()='502 Bad Gateway']")).size() > 0) {
						driver.navigate().refresh();
					}
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//th[text()='Category']")));
				} catch (Exception e) {
					driver.navigate().refresh();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//th[text()='Category']")));
				}

			}
			driver.quit();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * getCurrentDate() - Get the current system which is needed while creating Nike
	 * Account for generating name for email ID
	 * 
	 ************************************************************************************************************************/
	public static String getCurrentDate() {
		String systemDate = "";
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
			Date date = new Date();
			systemDate = formatter.format(date).toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDate;
	}

	/************************************************************************************************************************
	 * getPastDate() - Get the Past Date based on Passed Parameter
	 * 
	 ************************************************************************************************************************/
	public static String getPastDate(int i) {
		String yesterdayDate = "";
		try {
			// to get calendar instance
			Calendar cal = Calendar.getInstance();

			// subtract 1 from calendar current date
			cal.add(Calendar.DATE, -i);

			// format date
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

			// get formatted date
			yesterdayDate = dateFormat.format(cal.getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return yesterdayDate;
	}

	/************************************************************************************************************************
	 * updateTextFile() - Updates the text file with Information about the file
	 * which is processed so that it will not be processed in next run
	 * 
	 ************************************************************************************************************************/
	public static void updateTextFile(String fileName) {
		try {
			// Defining the File Reader and writer Details
			FileWriter writer = new FileWriter("ProcessedFiles.txt", true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(fileName);
			bufferedWriter.newLine();
			bufferedWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * checkFileName() - Checks whether File is already processed by checking in
	 * Processed Files text file and return true if its already processed
	 * 
	 ************************************************************************************************************************/
	public static Boolean checkFileName(String fileName) {
		Boolean value = false;
		try {
			// Defining the File Reader and writer Details
			FileReader reader = new FileReader("ProcessedFiles.txt");
			BufferedReader bufferedReader = new BufferedReader(reader);
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				if (line.equalsIgnoreCase(fileName)) {
					value = true;
				}
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;

	}

	/************************************************************************************************************************
	 * createLogFile() - Creates Text file for Logging which will be placed under
	 * Logs Folder
	 * 
	 ************************************************************************************************************************/
	public static void createLogFile(String fileName) {
		try {
			// Defining the File Reader and writer Details

			FileWriter writer = new FileWriter("/Logs/Log_" + getCurrentDate() + ".txt", true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(fileName);
			bufferedWriter.newLine();
			bufferedWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * createLogFile() - Creates Text file for Logging which will be placed under
	 * Logs Folder
	 * 
	 ************************************************************************************************************************/
	public static String[] returnFoldername(String fileName) {
		String[] directories = null;
		try {
			File file = new File(fileName);
			directories = file.list(new FilenameFilter() {
				public boolean accept(File current, String name) {
					return new File(current, name).isDirectory();
				}
			});

		} catch (Exception e) {
			e.printStackTrace();
		}
		return directories;
	}

	/************************************************************************************************************************
	 * isFileExists() - Verifies whether file exists or not and wait until file
	 * created
	 * 
	 ************************************************************************************************************************/
	public static void isFileExists(File file) {
		try {
			Boolean value = file.exists();
			if (!value) {
				Thread.sleep(10000);
			}
			value = file.exists();
			if (!value) {
				isFileExists(file);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * createFolder() - Creates Folder based on passed parameter at source directory
	 * 
	 ************************************************************************************************************************/
	public static Boolean createFolder(String fileDirectory) {
		boolean bool = false;
		try {
			// Instantiate the File class
			File f1 = new File(fileDirectory);
			bool = f1.mkdir();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bool;
	}

	public static void checkVideoCompleted(String transmissionFolder) {
		try {
			// Executing the commands for creating the torrent File
			String command2 = "transmission-remote -l";
			String[] cmd2 = new String[3];
			cmd2[0] = "cmd";
			cmd2[1] = "/c";
			cmd2[2] = "cd " + transmissionFolder + " && " + command2;
			Process process = Runtime.getRuntime().exec(cmd2);

			// Reading the Command line Response and getting Hash Info Value
			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String json = "";
			int count = 0;
			while ((json = reader.readLine()) != null) {
				if (count == 1) {
					System.out.println(json);
					if (json.contains("100%")) {
						System.out.println("Download Completed");
					} else {
						Thread.sleep(30000);
						checkVideoCompleted(transmissionFolder);
					}
				}
				count = count + 1;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * isFileExists() - Verifies whether file exists or not and wait until file
	 * created
	 * 
	 ************************************************************************************************************************/
	public static void isFolderExists(String directoryName) {
		try {
			File directory = new File(directoryName);
			if (!directory.exists()) {
				Thread.sleep(6000);
				isFolderExists(directoryName);
				System.out.println("Video Still not downloaded retring");
			} else {
				copyFiles(directoryName);
				System.out.println("Copied the PDF Files");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void isDeleteOtherFiles(String directoryName) {
		try {
			File folder = new File(directoryName);
			File[] listOfFiles = folder.listFiles();

			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile()) {
					{
						System.out.println("File " + listOfFiles[i].getName());
						if (listOfFiles[i].getName().contains(".mp4") || listOfFiles[i].getName().contains(".mkv")
								|| listOfFiles[i].getName().contains(".wmv")
								|| listOfFiles[i].getName().contains(".avi")
								|| listOfFiles[i].getName().contains(".pdf") || listOfFiles[i].getName().contains(".kim") || listOfFiles[i].getName().contains(".url")) {
							System.out.println("File is Video File");
						} else {
							listOfFiles[i].delete();
							System.out.println("Deleted the other file");
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * copyFiles() - Copies all of the files from source to destination folder
	 * 
	 ************************************************************************************************************************/
	public static Boolean copyFiles(String fileDirectory) {
		boolean bool = false;
		try {
			// Instantiate the File class
			String sourceFolder = System.getProperty("user.dir") + "//USB campaign//";
			File sFile = new File(sourceFolder);
			File[] sourceFiles = sFile.listFiles();
			// let us copy each file to the target folder
			for (File fSource : sourceFiles) {
				File fTarget = new File(new File(fileDirectory), fSource.getName());
				copyFileUsingStream(fSource, fTarget);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return bool;
	}

	/**
	 * Copies a file using the File streams
	 * 
	 * @param source
	 * @param dest
	 */
	private static void copyFileUsingStream(File source, File dest) {
		InputStream is = null;
		OutputStream os = null;
		try {
			is = new FileInputStream(source);
			os = new FileOutputStream(dest);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = is.read(buffer)) > 0) {
				os.write(buffer, 0, length);
			}
		} catch (Exception ex) {
			System.out.println("Unable to copy file:" + ex.getMessage());
		} finally {
			try {
				is.close();
				os.close();
			} catch (Exception ex) {
			}
		}
	}

}
