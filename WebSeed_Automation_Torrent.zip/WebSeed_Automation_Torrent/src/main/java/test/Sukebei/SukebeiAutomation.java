package test.Sukebei;

import java.awt.List;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

/************************************************************************************************************************
 * Code for Creating Torrent file using WebTorrent Hybrid CLI, Uploading
 * Video/Torrent file to wasabi using AWS CLI and updating the magnet link to
 * MongoDB
 ************************************************************************************************************************/
@SuppressWarnings("deprecation")
public class SukebeiAutomation {
	public static void main(String[] args) throws IOException, InterruptedException, ParseException {

		Properties prop = CommonUtilities.ReadInputData.readPropertiesFile();
		String targetDirectoryFolder = prop.getProperty("target_directory_Folder").trim();
		String url = prop.getProperty("FCP_url").trim();
		String transmissionFolder = prop.getProperty("transmissionFolder").trim();
		String trackerInfo = prop.getProperty("tracker_Info").trim();
		downloadData(url, targetDirectoryFolder, transmissionFolder,trackerInfo);
	}

	/*************************************************************************************************************************
	 * createTorrentWebSeed() -
	 * 
	 ************************************************************************************************************************/
	@SuppressWarnings({ "resource", "unchecked", "rawtypes" })
	public static void downloadData(String URL, String sourceDirectory, String transmissionFolder,String trackerInfo) {
		try {
			// Defining Logging related object functions
			Logger logger = Logger.getLogger("MyLog");
			FileHandler fh;
			try {
				// This block configure the logger with handler and formatter
				fh = new FileHandler("Logs//" + "Log_" + getCurrentDate() + ".txt");
				logger.addHandler(fh);
				SimpleFormatter formatter = new SimpleFormatter();
				fh.setFormatter(formatter);
			} catch (Exception e) {
				e.printStackTrace();
			}

			// Navigating to FCP WebSite for downloading the data
			WebDriver driver;
			String homePath = System.getProperty("user.dir");
			System.setProperty("webdriver.chrome.driver", homePath + "\\Drivers\\chromedriver.exe");
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("intl.accept_languages", "ja");
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("prefs", chromePrefs);
			driver = new ChromeDriver(options);
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get(URL);
			FluentWait wait = new FluentWait<WebDriver>(driver).withTimeout(25, TimeUnit.SECONDS)
					.pollingEvery(3, TimeUnit.SECONDS).ignoring(Exception.class);
			try {
				if (driver.findElements(By.xpath("//h1[text()='502 Bad Gateway']")).size() > 0) {
					driver.navigate().refresh();
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//th[text()='Category']")));
			} catch (Exception e) {
				driver.navigate().refresh();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//th[text()='Category']")));
			}
			System.out.println("//td[contains(text(),'" + getPastDate(1) + "')]");
			wait.until(ExpectedConditions
					.visibilityOfElementLocated(By.xpath("//td[contains(text(),'" + getPastDate(1) + "')]")));
			wait.until(ExpectedConditions.visibilityOfElementLocated(
					By.xpath("//td[contains(text(),'" + getPastDate(1) + "')]/preceding-sibling::td[2]/a[2]")));
			java.util.List<WebElement> magnetLinks = driver.findElements(
					By.xpath("//td[contains(text(),'" + getPastDate(1) + "')]/preceding-sibling::td[2]/a[2]"));
			java.util.List<WebElement> videoTitle = driver.findElements(
					By.xpath("//td[contains(text(),'" + getPastDate(1) + "')]/preceding-sibling::td[3]/a"));

			for (int i = 0; i < magnetLinks.size(); i++) {
				logger.info("Fetched Yesterday Video with Maget URI :" + magnetLinks.get(i).getAttribute("href")
						+ " and Title:" + videoTitle.get(i).getText());
				String magnetLink = magnetLinks.get(i).getAttribute("href");
				String[] folderName = videoTitle.get(i).getText().split(" ");
				String directoryName = sourceDirectory +"\\"+folderName[1];
				System.out.println(sourceDirectory);
				System.out.println(folderName[1]);
				System.out.println(directoryName);
				char quotes = '"';
				
				//Removing the Torrent List
				String command = "transmission-remote -t all";
				System.out.println(command);
				logger.info(command);

				// Executing the commands for creating the torrent File
				String[] cmd = new String[3];
				cmd[0] = "cmd";
				cmd[1] = "/c";
				cmd[2] = "cd " + transmissionFolder + " && " + command;
				Process process = Runtime.getRuntime().exec(cmd);
				logger.info("Downloding File " + folderName[1] + " from FC2 Website");
								
				//Downloading the Files from FCP WebPage
				String command1 = "transmission-remote -a " + quotes + magnetLink + quotes + " --download-dir "
						+ sourceDirectory;
				System.out.println(command1);
				logger.info(command1);

				// Executing the commands for creating the torrent File
				String[] cmd1 = new String[3];
				cmd1[0] = "cmd";
				cmd1[1] = "/c";
				cmd1[2] = "cd " + transmissionFolder + " && " + command1;
				process = Runtime.getRuntime().exec(cmd1);
				logger.info("Downloding File " + folderName[1] + " from FC2 Website");

				// Reading the Command line Response to Check if the Download has started
				BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				String json = "";
				String s = null;
				while ((s = reader.readLine()) != null) {
					json = json + s;
					System.out.println(json);
					logger.info(json);
	            }
				BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
				String Error;
				while ((Error = stdError.readLine()) != null) {
					logger.info("Error while Downloading the files to FCP WebPage:" + Error);
				}

				// Wait Until the video Completes
				checkVideoCompleted(transmissionFolder);

				// Check whether video file exists and Copy the PDF files
				isFolderExists(directoryName);
				isDeleteOtherFiles(directoryName);
				
				//Creating a Torrent File
				String command2 = "transmission-create -o "+sourceDirectory +"\\"+folderName[1]+".torrent --tracker "+trackerInfo +" "+sourceDirectory +"\\" +folderName[1]+"\\";
				System.out.println(command2);
				logger.info(command2);

				// Executing the commands for creating the torrent File
				String[] cmd2 = new String[3];
				cmd2[0] = "cmd";
				cmd2[1] = "/c";
				cmd2[2] = "cd " + transmissionFolder + " && " + command2;
				Thread.sleep(4000);
				process = Runtime.getRuntime().exec(cmd2);

				// Reading the Command line Response and getting Hash Info Value
				reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				json = "";
				s = null;
				while ((s = reader.readLine()) != null) {
					json = json + s;
					System.out.println(json);
					logger.info(json);
				}
				
				//Wait until Torrent File is created
				File file1 = new File(sourceDirectory +"\\"+folderName[1]+".torrent");
				isFileExists(file1);

			}
			//driver.quit();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * getCurrentDate() - Get the current system which is needed while creating Nike
	 * Account for generating name for email ID
	 * 
	 ************************************************************************************************************************/
	public static String getCurrentDate() {
		String systemDate = "";
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
			Date date = new Date();
			systemDate = formatter.format(date).toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDate;
	}

	/************************************************************************************************************************
	 * getPastDate() - Get the Past Date based on Passed Parameter
	 * 
	 ************************************************************************************************************************/
	public static String getPastDate(int i) {
		String yesterdayDate = "";
		try {
			// to get calendar instance
			Calendar cal = Calendar.getInstance();

			// subtract 1 from calendar current date
			cal.add(Calendar.DATE, -i);

			// format date
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

			// get formatted date
			yesterdayDate = dateFormat.format(cal.getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return yesterdayDate;
	}

	/************************************************************************************************************************
	 * updateTextFile() - Updates the text file with Information about the file
	 * which is processed so that it will not be processed in next run
	 * 
	 ************************************************************************************************************************/
	public static void updateTextFile(String fileName) {
		try {
			// Defining the File Reader and writer Details
			FileWriter writer = new FileWriter("ProcessedFiles.txt", true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(fileName);
			bufferedWriter.newLine();
			bufferedWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * checkFileName() - Checks whether File is already processed by checking in
	 * Processed Files text file and return true if its already processed
	 * 
	 ************************************************************************************************************************/
	public static Boolean checkFileName(String fileName) {
		Boolean value = false;
		try {
			// Defining the File Reader and writer Details
			FileReader reader = new FileReader("ProcessedFiles.txt");
			BufferedReader bufferedReader = new BufferedReader(reader);
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				if (line.equalsIgnoreCase(fileName)) {
					value = true;
				}
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;

	}

	/************************************************************************************************************************
	 * createLogFile() - Creates Text file for Logging which will be placed under
	 * Logs Folder
	 * 
	 ************************************************************************************************************************/
	public static void createLogFile(String fileName) {
		try {
			// Defining the File Reader and writer Details

			FileWriter writer = new FileWriter("/Logs/Log_" + getCurrentDate() + ".txt", true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(fileName);
			bufferedWriter.newLine();
			bufferedWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * createLogFile() - Creates Text file for Logging which will be placed under
	 * Logs Folder
	 * 
	 ************************************************************************************************************************/
	public static String[] returnFoldername(String fileName) {
		String[] directories = null;
		try {
			File file = new File(fileName);
			directories = file.list(new FilenameFilter() {
				public boolean accept(File current, String name) {
					return new File(current, name).isDirectory();
				}
			});

		} catch (Exception e) {
			e.printStackTrace();
		}
		return directories;
	}

	/************************************************************************************************************************
	 * isFileExists() - Verifies whether file exists or not and wait until file
	 * created
	 * 
	 ************************************************************************************************************************/
	public static void isFileExists(File file) {
		try {
			Boolean value = file.exists();
			if (!value) {
				Thread.sleep(10000);
			}
			value = file.exists();
			if (!value) {
				isFileExists(file);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * createFolder() - Creates Folder based on passed parameter at source directory
	 * 
	 ************************************************************************************************************************/
	public static Boolean createFolder(String fileDirectory) {
		boolean bool = false;
		try {
			// Instantiate the File class
			File f1 = new File(fileDirectory);
			bool = f1.mkdir();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bool;
	}

	public static void checkVideoCompleted(String transmissionFolder) {
		try {
			// Executing the commands for creating the torrent File
			String command2 = "transmission-remote -l";
			String[] cmd2 = new String[3];
			cmd2[0] = "cmd";
			cmd2[1] = "/c";
			cmd2[2] = "cd " + transmissionFolder + " && " + command2;
			Process process = Runtime.getRuntime().exec(cmd2);

			// Reading the Command line Response and getting Hash Info Value
			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			String json = "";
			int count = 0;
			while ((json = reader.readLine()) != null) {
				if (count == 1) {
					System.out.println(json);
					if (json.contains("0%")) {
						System.out.println("Download Completed");
					} else {
						Thread.sleep(60000);
						checkVideoCompleted(transmissionFolder);
					}
				}
				count = count + 1;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * isFileExists() - Verifies whether file exists or not and wait until file
	 * created
	 * 
	 ************************************************************************************************************************/
	public static void isFolderExists(String directoryName) {
		try {
			File directory = new File(directoryName);
			if (!directory.exists()) {
				Thread.sleep(6000);
				isFolderExists(directoryName);
				System.out.println("Video Still not downloaded retring");
			} else {
				copyFiles(directoryName);
				System.out.println("Copied the PDF Files");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void isDeleteOtherFiles(String directoryName) {
		try {
			File folder = new File(directoryName);
			File[] listOfFiles = folder.listFiles();

			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isFile()) {
					{
						System.out.println("File " + listOfFiles[i].getName());
						if (listOfFiles[i].getName().contains(".mp4") || listOfFiles[i].getName().contains(".mkv")
								|| listOfFiles[i].getName().contains(".wmv")
								|| listOfFiles[i].getName().contains(".avi") || listOfFiles[i].getName().contains(".pdf")) {
                        System.out.println("File is Video File");
						}
						else
						{
							listOfFiles[i].delete();
							 System.out.println("Deleted the other file");
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * copyFiles() - Copies all of the files from source to destination folder
	 * 
	 ************************************************************************************************************************/
	public static Boolean copyFiles(String fileDirectory) {
		boolean bool = false;
		try {
			// Instantiate the File class
			String sourceFolder = System.getProperty("user.dir") + "//USB campaign//";
			File sFile = new File(sourceFolder);
			File[] sourceFiles = sFile.listFiles();
			// let us copy each file to the target folder
			for (File fSource : sourceFiles) {
				File fTarget = new File(new File(fileDirectory), fSource.getName());
				copyFileUsingStream(fSource, fTarget);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return bool;
	}

	/**
	 * Copies a file using the File streams
	 * 
	 * @param source
	 * @param dest
	 */
	private static void copyFileUsingStream(File source, File dest) {
		InputStream is = null;
		OutputStream os = null;
		try {
			is = new FileInputStream(source);
			os = new FileOutputStream(dest);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = is.read(buffer)) > 0) {
				os.write(buffer, 0, length);
			}
		} catch (Exception ex) {
			System.out.println("Unable to copy file:" + ex.getMessage());
		} finally {
			try {
				is.close();
				os.close();
			} catch (Exception ex) {
			}
		}
	}

}
