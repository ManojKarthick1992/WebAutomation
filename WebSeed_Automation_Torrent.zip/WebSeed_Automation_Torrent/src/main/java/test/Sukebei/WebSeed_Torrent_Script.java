package test.Sukebei;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import org.apache.commons.io.FilenameUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;
import org.json.simple.parser.ParseException;

/************************************************************************************************************************
 * Code for Creating Torrent file using WebTorrent Hybrid CLI, Uploading
 * Video/Torrent file to wasabi using AWS CLI and updating the magnet link to
 * MongoDB
 ************************************************************************************************************************/
@SuppressWarnings("deprecation")
public class WebSeed_Torrent_Script {
	public static void main(String[] args) throws IOException, InterruptedException, ParseException {
		String sourceDirectory = "C:\\Users\\manoj\\Dropbox\\My PC (LAPTOP-71ALODVQ)\\Downloads";
		String transmissionFolder="C:\\Program Files\\Transmission";
		String trackerInfo ="http://sukebei.tracker.wf:8888/announce";
			
		//Creating a Torrent File
		String filePath = sourceDirectory +"\\"+"FC2-PPV-1876178"+".torrent";
		String filePath1 = sourceDirectory +"\\" +"FC2-PPV-1876178"+"\\";
		String command2 = "transmission-create -o "+filePath+" --tracker "+trackerInfo +" "+filePath1;
		System.out.println(command2);

		// Executing the commands for creating the torrent File
		String[] cmd2 = new String[3];
		cmd2[0] = "cmd";
		cmd2[1] = "/c";
		cmd2[2] = "cd " + sourceDirectory + " && " + command2;
		Thread.sleep(4000);
		Process process = Runtime.getRuntime().exec(cmd2);
		Thread.sleep(4000);
		Thread.sleep(4000);
		 // Reading the Command line Response and getting Hash Info Value
		  BufferedReader reader = new BufferedReader(new
		  InputStreamReader(process.getInputStream())); 
		  String json = ""; 
		  String s =null;
		  while ((s = reader.readLine()) != null) { 
	      json = json + s;
		  System.out.println(json); 
		  }
		
		BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
		String Error;
		while ((Error = stdError.readLine()) != null) {
			System.out.println("Error while Downloading the files to FCP WebPage:" + Error);
		}

		
		 
		 
		
	}

	/*************************************************************************************************************************
	 * createTorrentWebSeed() - Creates Torrent file using WebTorrent Hybrid CLI,
	 * Uploads Video/Torrent file to wasabi using AWS CLI and updates the the
	 * MongoDB with magnet link for videos in Target Folder "WebSeed-files" &
	 * "WebSeed-folder"
	 * 
	 ************************************************************************************************************************/
	@SuppressWarnings("resource")
	public static void createTorrentWebSeed(String targetDirectoryFiles, String targetDirectoryFolder,
			String apiServer) {
		try {
			// Defining Logging related object functions
			Logger logger = Logger.getLogger("MyLog");
			FileHandler fh;
			try {
				// This block configure the logger with handler and formatter
				fh = new FileHandler("Logs//" + "Log_" + getCurrentDate() + ".txt");
				logger.addHandler(fh);
				SimpleFormatter formatter = new SimpleFormatter();
				fh.setFormatter(formatter);
			} catch (Exception e) {
				e.printStackTrace();
			}

			// Defining the Target folder 'WebSeed-files' from where video files will be
			// uploaded
			String targetFolder = targetDirectoryFiles;
			File file = new File(targetFolder);
			FilenameUtils.getExtension(targetFolder);
			String[] fileList = file.list();
			for (String str : fileList) {
				if (str.contains(".mp4") || str.contains(".mkv") || str.contains(".wmv") || str.contains(".avi")) {
					String fileExt = FilenameUtils.getExtension(str);
					String[] name = str.split("." + fileExt);
					String fileName = name[0];
					Boolean value = checkFileName(str);
					if (!value) {
						String command1 = "webtorrent-hybrid create " + str + " -o " + fileName + ".torrent";
						String command2 = "webtorrent-hybrid info " + fileName + ".torrent";

						// Executing the commands for creating the torrent File
						String[] cmd1 = new String[3];
						cmd1[0] = "cmd";
						cmd1[1] = "/c";
						cmd1[2] = "cd " + targetFolder + " && " + command1;
						Process process = Runtime.getRuntime().exec(cmd1);

						// Check if the Torrent File is created and Wait for 10 Seconds if Torrent file
						// is not created
						File file1 = new File(targetFolder + "\\" + fileName + ".torrent");
						isFileExists(file1);
						logger.info("Created Torrent file for Video: '" + str + "'");

						// Fetch the HashInfo from Command Line Response
						String[] cmd2 = new String[3];
						cmd2[0] = "cmd";
						cmd2[1] = "/c";
						cmd2[2] = "cd " + targetFolder + " && " + command2;
						process = Runtime.getRuntime().exec(cmd2);

						// Reading the Command line Response and getting Hash Info Value
						BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
						String json = "";
						String s = null;
						while ((s = reader.readLine()) != null) {
							json = json + s;
						}
						JSONObject jObject = new JSONObject(json);
						String hashInfo = jObject.get("infoHash").toString();
						updateTextFile(str);

						// Connecting to AWS for moving Video file to wasabi
						String command3 = "aws s3 mv " + str
								+ " s3://seeds/manoj/ --acl public-read --endpoint-url=https://s3.us-central-1.wasabisys.com";
						String[] cmd3 = new String[3];
						cmd3[0] = "cmd";
						cmd3[1] = "/c";
						cmd3[2] = "cd " + targetFolder + " && " + command3;
						process = Runtime.getRuntime().exec(cmd3);
						logger.info("Moved Video File '" + str + "' to wasabi");

						// Connecting to AWS for moving Torrent file to wasabi
						String command4 = "aws s3 mv " + fileName
								+ ".torrent s3://seeds/manoj/ --acl public-read --endpoint-url=https://s3.us-central-1.wasabisys.com";
						String[] cmd4 = new String[3];
						cmd4[0] = "cmd";
						cmd4[1] = "/c";
						cmd4[2] = "cd " + targetFolder + " && " + command4;
						process = Runtime.getRuntime().exec(cmd4);
						logger.info("Moved Torrent File '" + fileName + ".torrent' to wasabi");

						BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));

						String Error;
						while ((Error = stdError.readLine()) != null) {
							logger.info("Error while Uploading the files to wasabi:" + Error);
						}

						// Updating the details to Mongo Database
						DefaultHttpClient httpClient = new DefaultHttpClient();

						// Define a postRequest request
						HttpPost postRequest = new HttpPost(apiServer + "/movie/update-uri");

						// Set the API media type in HTTP content-type header
						postRequest.addHeader("content-type", "application/json");

						// Set the details in PayLoad
						String payload = "{\r\n" + " \"key\":\"AUTO-77498432568\",\r\n" + " \"code\":\"" + fileName
								+ "\",\"link\":\"magnet:?xt=urn:btih:" + hashInfo + "&dn=" + str
								+ "&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969&tr=udp%3A%2F%2Ftracker.coppersurfer.tk%3A6969&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337&tr=udp%3A%2F%2Fexplodie.org%3A6969&tr=udp%3A%2F%2Ftracker.empire-js.us%3A1337&tr=wss%3A%2F%2Ftracker.fastcast.nz&tr=wss%3A%2F%2Ftracker.openwebtorrent.com&ws=https%3A%2F%2Fs3.us-central-1.wasabisys.com%2Fseeds%2Fmanoj%2F"
								+ str + "&xs=https%3A%2F%2Fs3.us-central-1.wasabisys.com%2Fseeds%2Fmanoj%2F" + fileName
								+ ".torrent\"\r\n" + "}\r\n" + "";

						// Set the request post body
						StringEntity userEntity = new StringEntity(payload);
						postRequest.setEntity(userEntity);

						// Send the request; It will immediately return the response in HttpResponse
						// object if any
						HttpResponse response = httpClient.execute(postRequest);

						// verify the valid error code first
						int statusCode = response.getStatusLine().getStatusCode();
						if (statusCode != 200) {
							logger.info("Error in updating Mongo DB for Video file '" + str + "' with status code:"
									+ statusCode + " for the Post API");
						} else {
							logger.info("Updated Mongo DB with Webseed Details for the Video file '" + str + "' is "
									+ payload);
						}
					} else {
						continue;
					}
				}

			}

			// Creating Torrent File for all of the folders at 'WebSeed-folders'
			String targetFolder1 = targetDirectoryFolder;
			System.out.println(targetFolder1);
			String[] folderNames = returnFoldername(targetFolder1);
			for (int j = 0; j < folderNames.length; j++) {
				// Creating Torrent file for the folder
				String command1 = "webtorrent-hybrid create " + folderNames[j] + "/ -o " + folderNames[j] + ".torrent";
				System.out.println(command1);
				String[] cmd1 = new String[3];
				cmd1[0] = "cmd";
				cmd1[1] = "/c";
				cmd1[2] = "cd " + targetFolder1 + " && " + command1;
				Process process = Runtime.getRuntime().exec(cmd1);

				// is not created
				File file1 = new File(targetFolder + "\\" + folderNames[j] + ".torrent");
				if (!file1.exists()) {
					Thread.sleep(15000);
				}

				// Getting HashInfo from command line response for the torrent file
				String command2 = "webtorrent-hybrid info " + folderNames[j] + ".torrent";
				System.out.println(command2);
				String[] cmd2 = new String[3];
				cmd2[0] = "cmd";
				cmd2[1] = "/c";
				cmd2[2] = "cd " + targetFolder1 + " && " + command2;
				process = Runtime.getRuntime().exec(cmd2);
				logger.info("Created Torrent File for the Folder '" + folderNames[j] + "'");

				// Reading the Command line Response and getting Hash Info Value
				BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
				String json = "";
				String s = null;
				while ((s = reader.readLine()) != null) {
					json = json + s;
				}
				JSONObject jObject = new JSONObject(json);
				String hashInfo = jObject.get("infoHash").toString();

				// Sync S3 with Local from 'WebSeed-folders'
				String command3 = "aws s3 sync . s3://seeds/manoj/ --acl public-read --endpoint-url=https://s3.us-central-1.wasabisys.com";
				String[] cmd3 = new String[3];
				cmd3[0] = "cmd";
				cmd3[1] = "/c";
				cmd3[2] = "cd " + targetFolder1 + " && " + command3;
				process = Runtime.getRuntime().exec(cmd3);
				logger.info("Synced S3 with Local from WebSeed Folder :" + folderNames[j]);

				BufferedReader stdError = new BufferedReader(new InputStreamReader(process.getErrorStream()));
				String Error;
				while ((Error = stdError.readLine()) != null) {
					System.out.println(Error);
				}

				// Updating the details to Mongo Database
				DefaultHttpClient httpClient = new DefaultHttpClient();

				// Define a postRequest request
				HttpPost postRequest = new HttpPost(apiServer + "/movie/update-uri");

				// Set the API media type in HTTP content-type header
				postRequest.addHeader("content-type", "application/json");

				// Set the details in PayLoad
				String payload = "{\r\n" + " \"key\":\"AUTO-77498432568\",\r\n" + " \"code\":\"" + folderNames[j]
						+ "\",\"link\":\"magnet:?xt=urn:btih:" + hashInfo + "&dn=" + folderNames[j]
						+ "&tr=udp%3A%2F%2Ftracker.leechers-paradise.org%3A6969&tr=udp%3A%2F%2Ftracker.coppersurfer.tk%3A6969&tr=udp%3A%2F%2Ftracker.opentrackr.org%3A1337&tr=udp%3A%2F%2Fexplodie.org%3A6969&tr=udp%3A%2F%2Ftracker.empire-js.us%3A1337&tr=wss%3A%2F%2Ftracker.fastcast.nz&tr=wss%3A%2F%2Ftracker.openwebtorrent.com&ws=https%3A%2F%2Fs3.us-central-1.wasabisys.com%2Fseeds%2Fmanoj%2F"
						+ folderNames[j] + "&xs=https%3A%2F%2Fs3.us-central-1.wasabisys.com%2Fseeds%2Fmanoj%2F"
						+ folderNames[j] + ".torrent\"\r\n" + "}\r\n" + "";

				// Set the request post body
				StringEntity userEntity = new StringEntity(payload);
				postRequest.setEntity(userEntity);

				// Send the request; It will immediately return the response in HttpResponse
				// object if any
				HttpResponse response = httpClient.execute(postRequest);

				// verify the valid error code first
				int statusCode = response.getStatusLine().getStatusCode();
				if (statusCode != 200) {
					logger.info("Error in updating Mongo DB for folder " + folderNames[j] + " with status code:"
							+ statusCode + " for the Post API");
				} else {
					logger.info("Updated Mongo DB with Webseed Details for the folder '" + folderNames[j] + "' is "
							+ payload);
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * getCurrentDate() - Get the current system which is needed while creating Nike
	 * Account for generating name for email ID
	 * 
	 ************************************************************************************************************************/
	public static String getCurrentDate() {
		String systemDate = "";
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
			Date date = new Date();
			systemDate = formatter.format(date).toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDate;
	}

	/************************************************************************************************************************
	 * updateTextFile() - Updates the text file with Information about the file
	 * which is processed so that it will not be processed in next run
	 * 
	 ************************************************************************************************************************/
	public static void updateTextFile(String fileName) {
		try {
			// Defining the File Reader and writer Details
			FileWriter writer = new FileWriter("ProcessedFiles.txt", true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(fileName);
			bufferedWriter.newLine();
			bufferedWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * checkFileName() - Checks whether File is already processed by checking in
	 * Processed Files text file and return true if its already processed
	 * 
	 ************************************************************************************************************************/
	public static Boolean checkFileName(String fileName) {
		Boolean value = false;
		try {
			// Defining the File Reader and writer Details
			FileReader reader = new FileReader("ProcessedFiles.txt");
			BufferedReader bufferedReader = new BufferedReader(reader);
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				if (line.equalsIgnoreCase(fileName)) {
					value = true;
				}
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return value;

	}

	/************************************************************************************************************************
	 * createLogFile() - Creates Text file for Logging which will be placed under
	 * Logs Folder
	 * 
	 ************************************************************************************************************************/
	public static void createLogFile(String fileName) {
		try {
			// Defining the File Reader and writer Details

			FileWriter writer = new FileWriter("/Logs/Log_" + getCurrentDate() + ".txt", true);
			BufferedWriter bufferedWriter = new BufferedWriter(writer);
			bufferedWriter.write(fileName);
			bufferedWriter.newLine();
			bufferedWriter.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/************************************************************************************************************************
	 * createLogFile() - Creates Text file for Logging which will be placed under
	 * Logs Folder
	 * 
	 ************************************************************************************************************************/
	public static String[] returnFoldername(String fileName) {
		String[] directories = null;
		try {
			File file = new File(fileName);
			directories = file.list(new FilenameFilter() {
				public boolean accept(File current, String name) {
					return new File(current, name).isDirectory();
				}
			});

		} catch (Exception e) {
			e.printStackTrace();
		}
		return directories;
	}

	/************************************************************************************************************************
	 * isFileExists() - Verifies whether file exists or not and wait until file
	 * created
	 * 
	 ************************************************************************************************************************/
	public static void isFileExists(File file) {
		try {
			Boolean value = file.exists();
			if (!value) {
				Thread.sleep(10000);
			}
			value = file.exists();
			if (!value) {
				isFileExists(file);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
