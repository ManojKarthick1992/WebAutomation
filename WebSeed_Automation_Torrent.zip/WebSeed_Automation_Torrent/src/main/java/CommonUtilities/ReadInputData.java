package CommonUtilities;

import java.io.File;
import java.io.FileInputStream;

import java.util.Properties;

public class ReadInputData {


	public static Properties readPropertiesFile() {
		Properties prop = new Properties();
		try {
			String homePath = System.getProperty("user.dir");
			File file = new File(homePath +"\\Sukebei.properties");
			FileInputStream fileInput = new FileInputStream(file);
			prop.load(fileInput);
		}

		catch (Exception e) {
			e.printStackTrace();
		}
		return prop;
	}

}
