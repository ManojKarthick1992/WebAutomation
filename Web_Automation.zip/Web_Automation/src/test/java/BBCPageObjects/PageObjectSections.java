package BBCPageObjects;

import org.openqa.selenium.WebDriver;

public class PageObjectSections {

    WebDriver driver;

    public PageObjectSections(WebDriver driver)
    {
        this.driver = driver;
    }

    public void SectionClick(String section)
    {
        switch (section){

        }
    }
}
