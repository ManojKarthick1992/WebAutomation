package BBCPageObjects;

import org.openqa.selenium.WebDriver;

public class PageObjectSearch {

    WebDriver driver;

    public PageObjectSearch(WebDriver driver)
    {
        this.driver = driver;
    }

}
