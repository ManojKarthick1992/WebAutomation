package test.BBC;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BBCTests {

    WebDriver driver;

    @BeforeEach
    public void setup()
    {
        System.setProperty("webdriver.chrome.driver", "/Users/stefa/Downloads/chromedriver.exe");
        driver = new ChromeDriver();

        //Go to BBC and disable cookies dialogue
        driver.get("https://www.bbc.com/news/world");
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        driver.switchTo().activeElement().sendKeys(Keys.TAB);
        driver.switchTo().activeElement().sendKeys(Keys.ENTER);

    }

    @AfterEach
    public void teardown()
    {
        driver.quit();
    }

    @Test
    public void testBBCSearch() throws Exception
    {
        //will return a Web element object
        WebElement searchbox = driver.findElement(By.name("q"));
        searchbox.sendKeys("Churchill");

        WebElement searchField = driver.findElement(By.id("orb-search-button"));
        searchField.click();

        //Verify
        String title = driver.getTitle();
        Assertions.assertEquals("BBC - Search results for Churchill", title);

    }
}
