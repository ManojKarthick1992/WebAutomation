package test.BBC;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;

public class StepDefs{
	WebDriver driver;
	
	@Given("I am user of news website and navigates to BBC Website")
	public void navigateBBCNews() throws Exception {
		String homePath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", homePath + "\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.bbc.com/news");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		@SuppressWarnings("unused")
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
		Thread.sleep(2000);
	}

	@When("I visit the BBC news website")
	public void validateBBCSite() throws InterruptedException {
	String pageTitle=driver.getTitle();
	Assertions.assertEquals("Home - BBC News",pageTitle);
	}

	@And("I click on World section under BBC Home page")
	public void clickWorld() throws InterruptedException {
		WebElement world = driver.findElement(By.xpath("(//span[text()='World'])[1]"));
		world.click();
		Thread.sleep(2000);		
	}

	@Then("I should taken to World section")
	public void checkWorld() throws InterruptedException {
		String pageTitle = driver.getTitle();
		Assertions.assertEquals("World - BBC News",pageTitle);
	}
	
	@And("World section should have stories")
	public void checkWorldStory() throws InterruptedException {
		List<WebElement> worldStories = driver.findElements(By.xpath("//h3[contains(@class,'heading__title')]"));
		int storyCount = worldStories.size();
		if(storyCount==0)
		{
			Assertions.fail("No Story is getting displayed under World section");
		}
	}

	@And("I click on Business section under BBC Home page")
	public void clickBusiness() throws InterruptedException {
		WebElement business = driver.findElement(By.xpath("(//span[text()='Business'])[1]"));
		business.click();
		Thread.sleep(2000);		
	}

	@Then("I should taken to Business section")
	public void checkBusiness() throws InterruptedException {
		String pageTitle = driver.getTitle();
		Assertions.assertEquals("Business - BBC News",pageTitle);
	}
	
	@And("Business section should have stories")
	public void checkBusinessStory() throws InterruptedException {
		List<WebElement> businessStories = driver.findElements(By.xpath("//h3[contains(@class,'heading__title')]"));
		int storyCount = businessStories.size();
		if(storyCount==0)
		{
			Assertions.fail("No Story is getting displayed under Business section");
		}
	}
	
	@And("I click on Tech section under BBC Home page")
	public void clickTech() throws InterruptedException {
		WebElement tech = driver.findElement(By.xpath("(//span[text()='Tech'])[1]"));
		tech.click();
		Thread.sleep(2000);		
	}

	@Then("I should taken to Tech section")
	public void checkTech() throws InterruptedException {
		String pageTitle = driver.getTitle();
		Assertions.assertEquals("Technology - BBC News",pageTitle);
	}
	
	@And("Tech section should have stories")
	public void checkTechStory() throws InterruptedException {
		List<WebElement> techStories = driver.findElements(By.xpath("//h3[contains(@class,'heading__title')]"));
		int storyCount = techStories.size();
		if(storyCount==0)
		{
			Assertions.fail("No Story is getting displayed under Technology section");
		}
	}
	
	@And("I click on Science section under BBC Home page")
	public void clickScience() throws InterruptedException {
		WebElement science = driver.findElement(By.xpath("(//span[text()='Science'])[1]"));
		science.click();
		Thread.sleep(2000);		
	}

	@Then("I should taken to Science section")
	public void checkScience() throws InterruptedException {
		String pageTitle = driver.getTitle();
		Assertions.assertEquals("Science & Environment - BBC News",pageTitle);
	}
	
	@And("Science section should have stories")
	public void checkScienceStory() throws InterruptedException {
		List<WebElement> scienceStories = driver.findElements(By.xpath("//h3[contains(@class,'heading__title')]"));
		int storyCount = scienceStories.size();
		if(storyCount==0)
		{
			Assertions.fail("No Story is getting displayed under Science section");
		}
	}
	
	@And("I click on Health section under BBC Home page")
	public void clickHealth() throws InterruptedException {
		WebElement health = driver.findElement(By.xpath("(//span[text()='Health'])[1]"));
		health.click();
		Thread.sleep(2000);		
	}

	@Then("I should taken to Health section")
	public void checkHealth() throws InterruptedException {
		String pageTitle = driver.getTitle();
		Assertions.assertEquals("Health - BBC News",pageTitle);
	}
	
	@And("Health section should have stories")
	public void checkHealthStory() throws InterruptedException {
		List<WebElement> healthStories = driver.findElements(By.xpath("//h3[contains(@class,'heading__title')]"));
		int storyCount = healthStories.size();
		if(storyCount==0)
		{
			Assertions.fail("No Story is getting displayed under Health section");
		}
		driver.quit();
	}
	
	
	@Given("I am user of news website and navigates to BBC Search page")
	public void searchPage() throws Exception {
		String homePath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", homePath + "\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.bbc.com/news");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		@SuppressWarnings("unused")
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
		Thread.sleep(2000);
		WebElement searchBar=driver.findElement(By.xpath("//input[@placeholder='Search']"));
		searchBar.click();
	}
	
	@When("I search for stories about 'Donald Trump'")
	public void searchInput() throws Exception {
		WebElement searchBar=driver.findElement(By.xpath("//input[@placeholder='Search']"));
		searchBar.sendKeys("Donald Trump");	
		Thread.sleep(1000);
		WebElement searchButton=driver.findElement(By.xpath("//button[text()='Search the BBC']"));
		searchButton.click();
		Thread.sleep(2000);
		@SuppressWarnings("unused")
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
		
	}
	
	@Then("I should see the search results")
	public void searchResults() throws Exception {
		WebElement searchResults=driver.findElement(By.xpath("(//a[contains(@class,'PromoLink')])[1]"));
		Boolean isResultsDisplay = searchResults.isDisplayed();
		if(!isResultsDisplay)
		{	
			Assertions.fail("No Search result is getting displayed");
		}
	}
	
	@And("There should be atleast Five stories in the search results")
	public void validateResults() throws Exception {
		 List<WebElement>elements = driver.findElements(By.xpath("(//a[contains(@class,'PromoLink')])/span"));
		 int storyCount = elements.size();
		 if(storyCount==0)
		 {
			 Assertions.fail("No Story is getting displayed under search results");
		 }
	}
	
	@When("I Click on First story in the results")
	public void clickStory() throws Exception {
		WebElement searchResults=driver.findElement(By.xpath("(//a[contains(@class,'PromoLink')])[1]"));
		searchResults.click();
		Thread.sleep(2000);
		@SuppressWarnings("unused")
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
	}
	
	@Then("I should be taken to the story")
	public void storyNavigate() throws Exception {
		String pageTitle = driver.getTitle();
		if(!pageTitle.contains("Trump"))
		{
			Assertions.fail("Not navigated to Story related to Donald Trump");
		}
    	driver.quit();
	}
	
	@Given("I am user of news website and navigates to BBC More Options section")
	public void navigateMoreOptions() throws Exception {
		String homePath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", homePath + "\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.bbc.com/news");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		@SuppressWarnings("unused")
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
		Thread.sleep(2000);
		WebElement moreOption=driver.findElement(By.xpath("//a[text()='More']"));
		moreOption.click();
	}
	
	@When("I click on Music section")
	public void clickMusic() throws InterruptedException {
		WebElement element = driver.findElement(By.xpath("(//a[text()='Music'])[2]"));
		element.click();
		Thread.sleep(2000);
}

	@Then("It should display Music Page")
	public void checkMusic() throws InterruptedException {
		String pageTitle = driver.getTitle();
		Assertions.assertEquals("Music - BBC Culture",pageTitle);
		
}
	
	@When("I click on Weather section")
	public void clickTV() throws InterruptedException {
		WebElement moreOption=driver.findElement(By.xpath("//a[text()='More']"));
		moreOption.click();
		Thread.sleep(2000);
		WebElement element = driver.findElement(By.xpath("(//a[text()='Weather'])[2]"));
		element.click();
		Thread.sleep(2000);
}


	@Then("It should display Weather Page")
	public void checkWeather() throws InterruptedException {
		String pageTitle = driver.getTitle();
		Assertions.assertEquals("BBC Weather",pageTitle);
}
	
	@When("I click on Sounds section")
	public void clickSound() throws InterruptedException {
		WebElement moreOption=driver.findElement(By.xpath("//a[text()='More']"));
		moreOption.click();
		Thread.sleep(2000);
		WebElement element = driver.findElement(By.xpath("(//a[text()='Sounds'])[2]"));
		element.click();
		Thread.sleep(2000);
}


	@Then("It should display Sounds Page")
	public void checkSound() throws InterruptedException {
		String pageTitle = driver.getTitle();
		Assertions.assertEquals("BBC Sounds - Music. Radio. Podcasts",pageTitle);
		driver.quit();
}
	
}
