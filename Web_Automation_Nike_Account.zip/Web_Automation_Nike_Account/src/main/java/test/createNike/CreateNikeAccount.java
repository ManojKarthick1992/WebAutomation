package test.createNike;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;

import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.Assert;

/************************************************************************************************************************
 * Code Nike Account creation based on Number of Parameters passed
 * 
 ************************************************************************************************************************/

public class CreateNikeAccount {
	static WebDriver driver;

	public static void main(String[] args) throws IOException, InterruptedException {
		createNikeAccount(3);
	}

	/*************************************************************************************************************************
	 * createNikeAccount() - Creates Nike Accounts for number times based on passed
	 * input parameter 'numberofAccounts' and captures the created account details
	 * in excel under 'Nike Account Details' folder of 'src/main/resources' package
	 * 
	 ************************************************************************************************************************/
	@SuppressWarnings("unchecked")
	public static WebDriver createNikeAccount(int numberofAccounts) {
		try {
			// Defining the Input Excel File
			String filePath = System.getProperty("user.dir")
					+ "\\src\\main\\resources\\NikeAccountDetails\\NikeAccountDetails.xlsx";
			FileInputStream file = new FileInputStream(new File(filePath));
			ZipSecureFile.setMinInflateRatio(-1.0d);
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheetAt(0);
			XSSFRow row = sheet.getRow(0);
			XSSFCell cell = row.getCell(0);

			// Navigating to Nike WebSite and create Accounts
			String homePath = System.getProperty("user.dir");
			System.setProperty("webdriver.chrome.driver", homePath + "\\Drivers\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get("https://www.nike.com/gb/");
			Thread.sleep(2000);
			FluentWait wait = new FluentWait<WebDriver>(driver).withTimeout(25, TimeUnit.SECONDS)
					.pollingEvery(3, TimeUnit.SECONDS).ignoring(Exception.class);

			// Clearing previously created Nike Account Details in excel
			for (int rowIndex = 1; rowIndex <= sheet.getLastRowNum(); rowIndex++) {
				row = sheet.getRow(rowIndex);
				cell = row.createCell(0);
				cell.setCellValue("");
				cell = row.createCell(1);
				cell.setCellValue("");
				cell = row.createCell(2);
				cell.setCellValue("");
				cell = row.createCell(3);
				cell.setCellValue("");
				cell = row.createCell(4);
				cell.setCellValue("");
				cell = row.createCell(5);
				cell.setCellValue("");
				cell = row.createCell(6);
				cell.setCellValue("");
			}

			// Creating Nike Account and updating the details in excel
			for (int i = 0; i < numberofAccounts; i++) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(
						By.xpath("(//div[@id='HelpMenuDropdown']/following::span[text()='Join Us'])[1]")));
				wait.until(ExpectedConditions.elementToBeClickable(
						By.xpath("(//div[@id='HelpMenuDropdown']/following::span[text()='Join Us'])[1]")));
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", driver
						.findElement(By.xpath("(//div[@id='HelpMenuDropdown']/following::span[text()='Join Us'])[1]")));
				// driver.findElement(By.xpath("(//span[text()='Join Us'])[1]")).click();
				wait.until(
						ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Log in')]")));
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Log in')]")));
				Thread.sleep(3000);
				driver.findElement(By.xpath("//button[contains(text(),'Log in')]")).click();
				// executor.executeScript("arguments[0].click();",driver.findElement(By.xpath("//button[contains(text(),'Log
				// in')]")));
				wait.until(ExpectedConditions
						.visibilityOfElementLocated(By.xpath("(//a[contains(text(),'Join Us')])[1]")));
				driver.findElement(By.xpath("(//a[contains(text(),'Join Us')])[1]")).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='email']")));
				String email = "Nike_" + getCurrentDate() + "@gmail.com";
				driver.findElement(By.xpath("//input[@type='email']")).sendKeys(email);
				String password = "Nike@123";
				driver.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
				String firstName = "NikeFirst" + getAlphaNumericString(3);
				driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(firstName);
				String lastName = "NikeLast" + getAlphaNumericString(3);
				driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(lastName);
				String dob = getPastDate();
				driver.findElement(By.xpath("//input[@type='date']")).click();
				driver.findElement(By.xpath("//input[@type='date']")).sendKeys(dob);
				driver.findElement(By.xpath("//span[text()='Male']")).click();
				driver.findElement(By.xpath("//label[@class='checkbox']")).click();
				driver.findElement(By.xpath("//input[@value='JOIN US']")).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//p[contains(text(),'Hi')])[1]")));
				Actions actions = new Actions(driver);
				actions.moveToElement(driver.findElement(By.xpath("(//p[contains(text(),'Hi')])[1]"))).perform();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Log Out']")));
				driver.findElement(By.xpath("//button[text()='Log Out']")).click();
				row = sheet.createRow(i + 1);
				cell = row.createCell(0);
				cell.setCellValue(i + 1);
				cell = row.createCell(1);
				cell.setCellValue(email);
				cell = row.createCell(2);
				cell.setCellValue(password);
				cell = row.createCell(3);
				cell.setCellValue(firstName);
				cell = row.createCell(4);
				cell.setCellValue(lastName);
				cell = row.createCell(5);
				cell.setCellValue(dob);
				cell = row.createCell(6);
				cell.setCellValue(getCurrentDate1());

				// Updating the Excel Sheet with the changes
				FileOutputStream out = new FileOutputStream(new File(filePath));
				workbook.write(out);
				out.close();
			}
			driver.quit();

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
		return driver;

	}

	/************************************************************************************************************************
	 * getCurrentDate() - Get the current system which is needed while creating Nike
	 * Account for generating name for email ID
	 * 
	 ************************************************************************************************************************/
	public static String getCurrentDate() {
		String systemDate = "";
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
			Date date = new Date();
			systemDate = formatter.format(date).toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDate;
	}

	/****************************************************************************************************
	 * Returns the Current System Date
	 * 
	 *****************************************************************************************************/
	public static String getCurrentDate1() {
		String systemDate = "";
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			Date date = new Date();
			systemDate = formatter.format(date).toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDate;
	}

	/****************************************************************************************************
	 * getPastDate() - Returns the Past Date which is needed for entering Date of
	 * Birth 25 years back
	 * 
	 *****************************************************************************************************/
	public static String getPastDate() {
		String systemDate = "";
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-");
			DateFormat dateFormat1 = new SimpleDateFormat("yyyy");	
			GregorianCalendar cal = (GregorianCalendar) GregorianCalendar.getInstance();
			cal.add((GregorianCalendar.MONTH),3);
			String date = dateFormat.format(cal.getTime());
			cal.add((GregorianCalendar.YEAR),-25);
			String year = dateFormat1.format(cal.getTime());
			systemDate = date+year;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDate;
	}

	/************************************************************************************************************************
	 * getAlphaNumericString() - Generates Random String which is needed while
	 * creating Nike Account for generating First & Last Name
	 * 
	 ************************************************************************************************************************/
	static String getAlphaNumericString(int n) {

		// chose a Character random from this String
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvxyz";

		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

			// generate a random number between
			// 0 to AlphaNumericString variable length
			int index = (int) (AlphaNumericString.length() * Math.random());

			// add Character one by one in end of sb
			sb.append(AlphaNumericString.charAt(index));
		}

		return sb.toString();
	}

}
