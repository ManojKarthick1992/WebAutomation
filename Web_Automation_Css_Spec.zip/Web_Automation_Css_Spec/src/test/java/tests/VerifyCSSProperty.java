package tests;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;

/****************************************************************************************************
 * VerifyCSSProperty(URL) - Validates the CSS specification such as
 * width,height,margin,padding and background-color for Website based on Passed
 * URL
 * 
 *****************************************************************************************************/
public class VerifyCSSProperty {

	public static void main(String[] args) throws IOException, InterruptedException {
		validateCSSProperty("https://www.ril.com/OurCompany/Leadership/FounderChairman.aspx");
	}

	public static void validateCSSProperty(String URL) throws IOException, InterruptedException {
		WebDriver driver = null;
		String homePath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", homePath + "\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(URL);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		WebElement element = driver.findElement(By.xpath("//title/following::div"));

		// Checking whether CSS Specification Width is maintained for the WebPage
		if (element.getCssValue("width").isBlank()) {
			Assert.fail("CSS Specification width is not maintained for the WebPage:" + element.getCssValue("width"));
		} else {
			System.out.println("CSS Specification width is maintained for the WebPage:" + element.getCssValue("width"));
		}

		// Checking whether CSS Specification Height is maintained for the WebPage
		if (element.getCssValue("height").isBlank()) {
			Assert.fail("CSS Specification height is not maintained for the WebPage:" + element.getCssValue("height"));
		} else {
			System.out
					.println("CSS Specification height is maintained for the WebPage:" + element.getCssValue("height"));
		}

		// Checking whether CSS Specification margin is maintained for the WebPage
		if (element.getCssValue("margin").isBlank()) {
			Assert.fail("CSS Specification margin is not maintained for the WebPage:" + element.getCssValue("margin"));
		} else {
			System.out
					.println("CSS Specification margin is maintained for the WebPage:" + element.getCssValue("margin"));
		}

		// Checking whether CSS Specification Padding is maintained for the WebPage
		if (element.getCssValue("padding").isBlank()) {
			Assert.fail(
					"CSS Specification Padding is not maintained for the WebPage:" + element.getCssValue("padding"));
		} else {
			System.out.println(
					"CSS Specification Padding is maintained for the WebPage:" + element.getCssValue("padding"));
		}

		// Checking whether CSS Specification Background color is maintained for the
		// WebPage
		if (element.getCssValue("background-color").isBlank()) {
			Assert.fail("CSS Specification Background color is not maintained for the WebPage:"
					+ element.getCssValue("background-color"));
		} else {
			System.out.println("CSS Specification Background color is maintained for the WebPage:"
					+ element.getCssValue("background-color"));
		}
		driver.quit();

	}
}
