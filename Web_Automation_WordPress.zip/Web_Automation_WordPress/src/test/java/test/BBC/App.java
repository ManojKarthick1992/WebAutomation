package test.BBC;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Properties;
import java.net.URLConnection;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import WordpressPageObjects.AddNewPropertyPage;
import WordpressPageObjects.WordpressLoginPage;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException, InterruptedException
    {
    	WebDriver driver = null;
    	Properties prop=CommonUtilities.ReadInputData.readPropertiesFile();
    	String Browser_Username=prop.getProperty("browser_username").trim();
    	String Browser_Password=prop.getProperty("browser_password").trim();
    	String WordPress_user=prop.getProperty("wordpress_username").trim();
    	String wordpress_pswd=prop.getProperty("wordpress_password").trim();
    	String url=prop.getProperty("wordpress_url");
    	WordpressLoginPage wordpressLoginPage = new WordpressLoginPage(driver);
    	driver=wordpressLoginPage.wordPressLogin(url, Browser_Username, Browser_Password, WordPress_user, wordpress_pswd); 	
    	AddNewPropertyPage addNewPropertyPage = new AddNewPropertyPage(driver);
    	addNewPropertyPage.addNewProperty();
    }
}

