package test.createNike;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.concurrent.TimeUnit;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

/************************************************************************************************************************
 * Code Nike Account creation based on Number of Parameters passed
 * 
 ************************************************************************************************************************/

public class LoginNikeAccount {
	static WebDriver driver;

	public static void main(String[] args) throws IOException, InterruptedException {
		verifyNikeAccountLogin();
	}

	/*************************************************************************************************************************
	 * createNikeAccount() - Creates Nike Accounts for number times based on passed
	 * input parameter 'numberofAccounts' and captures the created account details
	 * in excel under 'Nike Account Details' folder of 'src/main/resources' package
	 * 
	 ************************************************************************************************************************/
	@SuppressWarnings("unchecked")
	public static WebDriver verifyNikeAccountLogin() {
		try {
			// Defining the Input Excel File
			String filePath = System.getProperty("user.dir")
					+ "\\src\\main\\resources\\NikeAccountDetails\\NikeAccountDetails_Login.xlsx";
			FileInputStream file = new FileInputStream(new File(filePath));
			ZipSecureFile.setMinInflateRatio(-1.0d);
			XSSFWorkbook workbook = new XSSFWorkbook(file);
			XSSFSheet sheet = workbook.getSheetAt(0);
			XSSFRow row = sheet.getRow(0);
			XSSFCell cell = row.getCell(0);

			// Navigating to Nike WebSite and create Accounts
			String homePath = System.getProperty("user.dir");

			// WebDriver driver = new EdgeDriver(c);
			System.setProperty("webdriver.edge.driver", homePath + "\\Drivers\\msedgedriver - Copy.exe");
			// WebDriver driver = new ChromeDriver(options);
			WebDriver driver = new EdgeDriver();

			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get("https://www.nike.com/gb/");
			Thread.sleep(2000);
			FluentWait wait = new FluentWait<WebDriver>(driver).withTimeout(35, TimeUnit.SECONDS)
					.pollingEvery(3, TimeUnit.SECONDS).ignoring(Exception.class);

			for (int i = 1; i < sheet.getLastRowNum(); i++) {
				row = sheet.getRow(i);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Sign In'])[1]")));
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Sign In'])[1]")));
				driver.findElement(By.xpath("(//span[text()='Sign In'])[1]")).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='email']")));
				cell = row.getCell(1);
				String email = cell.getStringCellValue().trim();
				driver.findElement(By.xpath("//input[@type='email']")).sendKeys(email);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@type='password']")));
				cell = row.getCell(2);
				String password = cell.getStringCellValue().trim();
				driver.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
				driver.findElement(By.xpath("//input[@value='SIGN IN']")).click();
				Thread.sleep(3000);
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[text()='Help'])[1]")));
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[text()='Help'])[1]")));
				Actions actions = new Actions(driver);
				actions.moveToElement(driver.findElement(By.xpath("(//span[text()='Help'])[1]"))).perform();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()='Order Status']")));
				driver.findElement(By.xpath("//a[text()='Order Status']")).click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//p[contains(text(),'Hi')])[1]")));
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//p[contains(text(),'Hi')])[1]")));
				actions.moveToElement(driver.findElement(By.xpath("(//p[contains(text(),'Hi')])[1]"))).perform();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Log Out']")));
				driver.findElement(By.xpath("//button[text()='Log Out']")).click();

				// Updating the Excel Sheet with the changes
				FileOutputStream out = new FileOutputStream(new File(filePath));
				workbook.write(out);
				out.close();

			}
			driver.quit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return driver;

	}

	/************************************************************************************************************************
	 * getCurrentDate() - Get the current system which is needed while creating Nike
	 * Account for generating name for email ID
	 * 
	 ************************************************************************************************************************/
	public static String getCurrentDate() {
		String systemDate = "";
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
			Date date = new Date();
			systemDate = formatter.format(date).toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDate;
	}

	/****************************************************************************************************
	 * Returns the Current System Date
	 * 
	 *****************************************************************************************************/
	public static String getCurrentDate1() {
		String systemDate = "";
		try {
			SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
			Date date = new Date();
			systemDate = formatter.format(date).toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDate;
	}

	/****************************************************************************************************
	 * getPastDate() - Returns the Past Date which is needed for entering Date of
	 * Birth 25 years back
	 * 
	 *****************************************************************************************************/
	public static String getPastDate() {
		String systemDate = "";
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-");
			DateFormat dateFormat1 = new SimpleDateFormat("yyyy");
			GregorianCalendar cal = (GregorianCalendar) GregorianCalendar.getInstance();
			cal.add((GregorianCalendar.MONTH), 3);
			String date = dateFormat.format(cal.getTime());
			cal.add((GregorianCalendar.YEAR), -25);
			String year = dateFormat1.format(cal.getTime());
			systemDate = date + year;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return systemDate;
	}

	/************************************************************************************************************************
	 * getAlphaNumericString() - Generates Random String which is needed while
	 * creating Nike Account for generating First & Last Name
	 * 
	 ************************************************************************************************************************/
	static String getAlphaNumericString(int n) {

		// chose a Character random from this String
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvxyz";

		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

			// generate a random number between
			// 0 to AlphaNumericString variable length
			int index = (int) (AlphaNumericString.length() * Math.random());

			// add Character one by one in end of sb
			sb.append(AlphaNumericString.charAt(index));
		}

		return sb.toString();
	}

}
