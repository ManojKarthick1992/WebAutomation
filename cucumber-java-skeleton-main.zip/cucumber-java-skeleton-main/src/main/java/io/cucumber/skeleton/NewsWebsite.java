package io.cucumber.skeleton;

public class NewsWebsite {
    public void eat(int cukes) {

    }
}
