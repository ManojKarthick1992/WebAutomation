package io.cucumber.skeleton;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Given;

public class StepDefinitions {

	WebDriver driver;
	public static Logger logger = Logger.getLogger(StepDefinitions.class);
	
	@Given("I am user of news website and navigates to BBC Website")
	public void navigateBBCNews() throws Exception {
		String homePath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", homePath + "\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.bbc.com/news");
		MyScreenRecorder.startRecording("webautomation_scenario1");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		@SuppressWarnings("unused")
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
		Thread.sleep(2000);
	}

	@When("I visit the BBC news website")
	public void validateBBCSite() throws InterruptedException {
		List<WebElement> elements = driver.findElements(By.xpath("//li[contains(@class,'menuitem-container')]/a/span"));
		logger.info("Below are the different sections available under BBC Website");
		for (int i = 0; i < elements.size(); i++) {
			elements = driver.findElements(By.xpath("//li[contains(@class,'menuitem-container')]/a/span"));
			String sectionName = elements.get(i).getText();
			logger.info(sectionName);
		}
	}

	@And("I click on different sections available under BBC Home page")
	public void clickonSectionName() throws InterruptedException {
		List<WebElement> elements = driver.findElements(By.xpath("//li[contains(@class,'menuitem-container')]/a/span"));
		for (int i = 2; i < 15; i++) {
			if (i != 3) {
				elements = driver.findElements(By.xpath("//li[contains(@class,'menuitem-container')]/a/span"));
				String sectionName = elements.get(i).getText();
				elements.get(i).click();
				Thread.sleep(2000);
				logger.info("Clicked on Section:" + sectionName);
			}
		}
	}

	@Then("I should be taken to respective sections under BBC")
	public void navigateSection() throws InterruptedException {
		List<WebElement> elements = driver.findElements(By.xpath("//li[contains(@class,'menuitem-container')]/a/span"));
		for (int i = 0; i < 15; i++) {
			elements = driver.findElements(By.xpath("//li[contains(@class,'menuitem-container')]/a/span"));
			String sectionName = elements.get(i).getText();
			logger.info("Navigated to news section:" + sectionName);
		}
	}

	@And("The section should have stories")
	public void navigateStory() throws Exception
	{
     List<WebElement>elements = driver.findElements(By.xpath("//li[contains(@class,'menuitem-container')]/a/span"));
	 for(int i=0;i<15;i++)
	 {   
		 elements = driver.findElements(By.xpath("//li[contains(@class,'menuitem-container')]/a/span"));
		 String sectionName = elements.get(i).getText();
		 logger.info("Story is available under section:"+sectionName);
	 }
	MyScreenRecorder.stopRecording();
 	driver.quit();
	}
	
	@Given("I am user of news website and navigates to BBC Search page")
	public void searchPage() throws Exception {
		String homePath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", homePath + "\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.bbc.com/news");
		MyScreenRecorder.startRecording("webautomation_scenario2");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		@SuppressWarnings("unused")
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
		Thread.sleep(2000);
		WebElement searchBar=driver.findElement(By.xpath("//input[@placeholder='Search']"));
		searchBar.click();
		logger.info("Navigated to BBC Website and clicked on Search Bar");

	}
	
	@When("I search for stories about 'Donald Trump'")
	public void searchInput() throws Exception {
		WebElement searchBar=driver.findElement(By.xpath("//input[@placeholder='Search']"));
		searchBar.sendKeys("Donald Trump");	
		Thread.sleep(1000);
		WebElement searchButton=driver.findElement(By.xpath("//button[text()='Search the BBC']"));
		searchButton.click();
		logger.info("Search Stories about Donald Trump");
		Thread.sleep(2000);
		@SuppressWarnings("unused")
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
		
	}
	
	@Then("I should see the search results")
	public void searchResults() throws Exception {
		WebElement searchResults=driver.findElement(By.xpath("(//a[contains(@class,'PromoLink')])[1]"));
		if(searchResults.isDisplayed())
		{
			logger.info("Story about Donald Trump are getting displayed");
		}
	}
	
	@And("There should be atleast Five stories in the search results")
	public void validateResults() throws Exception {
		 List<WebElement>elements = driver.findElements(By.xpath("(//a[contains(@class,'PromoLink')])/span"));
		 for(int i=0;i<elements.size();i++)
		 {   
			 String resultsName = elements.get(i).getText();
			 logger.info(resultsName+" story is available under search results");
		 }
	}
	
	@When("I Click on First story in the results")
	public void clickStory() throws Exception {
		WebElement searchResults=driver.findElement(By.xpath("(//a[contains(@class,'PromoLink')])[1]"));
		searchResults.click();
		logger.info("Clicked on First available Story");
		Thread.sleep(2000);
		@SuppressWarnings("unused")
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
	}
	
	@Then("I should be taken to the story")
	public void storyNavigate() throws Exception {
		String text = driver.findElement(By.xpath("//div[@class='br-masthead__title']/a")).getText().trim();
		logger.info("Navigated to Story: "+text);
    	MyScreenRecorder.stopRecording();
    	driver.quit();
	}
	
}
